# Que Palta no usa reflexión propia ni reglas ProGuard adicionales en esta versión.

package com.quepalta.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScanActivity extends AppCompatActivity {
    public static final String EXTRA_QR_VALUE = "com.quepalta.app.QR_VALUE";
    private PreviewView previewView;
    private ExecutorService cameraExecutor;
    private BarcodeScanner scanner;
    private final AtomicBoolean delivered = new AtomicBoolean(false);
    private ProcessCameraProvider cameraProvider;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(20, 52, 60));
        getWindow().setNavigationBarColor(Color.rgb(20, 52, 60));
        cameraExecutor = Executors.newSingleThreadExecutor();
        buildScannerInterface();
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .build();
        scanner = BarcodeScanning.getClient(options);
        startCamera();
    }

    private void buildScannerInterface() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(20, 52, 60));
        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(previewView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(22), dp(24), dp(22), dp(18));
        header.setBackgroundColor(0xCC14343C);
        TextView kicker = text("QUE PALTA  /  ESCÁNER", 11, 0xFF9FD8C6, true);
        TextView title = text("Encuentra tu misión", 25, Color.WHITE, true);
        TextView subtitle = text("Centra el código QR dentro del recuadro.", 14, 0xFFD4E3DE, false);
        header.addView(kicker); header.addView(title); header.addView(subtitle);
        FrameLayout.LayoutParams headerParams = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(header, headerParams);

        View frame = new View(this);
        FrameLayout.LayoutParams frameParams = new FrameLayout.LayoutParams(dp(250), dp(250), Gravity.CENTER);
        GradientDrawable guide = new GradientDrawable();
        guide.setColor(Color.TRANSPARENT);
        guide.setCornerRadius(dp(22));
        guide.setStroke(dp(3), Color.rgb(137, 221, 183));
        frame.setBackground(guide);
        frame.setElevation(dp(4));
        root.addView(frame, frameParams);

        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setGravity(Gravity.CENTER_HORIZONTAL);
        footer.setPadding(dp(24), dp(18), dp(24), dp(28));
        footer.setBackgroundColor(0xCC14343C);
        TextView hint = text("Cuando se detecte el QR, la misión se abrirá automáticamente.", 13, 0xFFE5EFE9, false);
        hint.setGravity(Gravity.CENTER);
        footer.addView(hint);
        Button cancel = new Button(this);
        cancel.setText("Cancelar escaneo");
        cancel.setAllCaps(false);
        cancel.setTextColor(Color.rgb(20,52,60));
        cancel.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(245,244,236)));
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(-1, dp(48));
        cancelParams.topMargin = dp(12);
        footer.addView(cancel, cancelParams);
        cancel.setOnClickListener(v -> finishCancelled());
        FrameLayout.LayoutParams footerParams = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(footer, footerParams);
        setContentView(root);
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value); text.setTextSize(sp); text.setTextColor(color);
        text.setTypeface(Typeface.create("sans-serif-condensed", bold ? Typeface.BOLD : Typeface.NORMAL));
        if (sp == 25) text.setPadding(0, dp(7), 0, dp(4));
        else text.setPadding(0, dp(3), 0, dp(3));
        return text;
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                cameraProvider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                ImageAnalysis analysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();
                analysis.setAnalyzer(cameraExecutor, imageProxy -> {
                    if (delivered.get()) { imageProxy.close(); return; }
                    android.media.Image mediaImage = imageProxy.getImage();
                    if (mediaImage == null) { imageProxy.close(); return; }
                    InputImage image = InputImage.fromMediaImage(mediaImage, imageProxy.getImageInfo().getRotationDegrees());
                    scanner.process(image)
                            .addOnSuccessListener(barcodes -> {
                                for (Barcode barcode : barcodes) {
                                    String raw = barcode.getRawValue();
                                    if (raw != null && delivered.compareAndSet(false, true)) {
                                        runOnUiThread(() -> finishWithValue(raw));
                                        break;
                                    }
                                }
                            })
                            .addOnCompleteListener(task -> imageProxy.close());
                });
                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
            } catch (Exception e) {
                finishCancelled();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void finishWithValue(String value) {
        Intent data = new Intent(); data.putExtra(EXTRA_QR_VALUE, value);
        setResult(Activity.RESULT_OK, data); finish();
    }

    private void finishCancelled() {
        setResult(Activity.RESULT_CANCELED); finish();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }

    @Override protected void onDestroy() {
        if (cameraProvider != null) cameraProvider.unbindAll();
        if (scanner != null) scanner.close();
        if (cameraExecutor != null) cameraExecutor.shutdown();
        super.onDestroy();
    }
}

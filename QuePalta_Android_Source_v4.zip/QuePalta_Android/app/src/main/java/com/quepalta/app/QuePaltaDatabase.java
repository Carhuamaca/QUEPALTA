package com.quepalta.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.Instant;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** SQLite local, normalizada. Además mantiene un snapshot para restaurar el estado exacto de la UI. */
public final class QuePaltaDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "que_palta.db";
    private static final int DB_VERSION = 3;

    public QuePaltaDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE app_state (id INTEGER PRIMARY KEY CHECK(id=1), state_json TEXT NOT NULL, saved_at TEXT NOT NULL)");
        db.execSQL("CREATE TABLE profiles (id INTEGER PRIMARY KEY CHECK(id=1), name TEXT NOT NULL, career TEXT NOT NULL, cohort TEXT NOT NULL, created_at TEXT NOT NULL, last_active TEXT, avatar_emoji TEXT NOT NULL DEFAULT '🥑', bio TEXT NOT NULL DEFAULT '')");
        db.execSQL("CREATE TABLE progress (id INTEGER PRIMARY KEY CHECK(id=1), xp INTEGER NOT NULL DEFAULT 0, last_active TEXT, coins INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE completed_missions (mission_id TEXT PRIMARY KEY, title TEXT NOT NULL, xp INTEGER NOT NULL, reflection TEXT, completed_at TEXT)");
        db.execSQL("CREATE TABLE mission_history (entry_id INTEGER PRIMARY KEY AUTOINCREMENT, mission_id TEXT NOT NULL, title TEXT NOT NULL, xp INTEGER NOT NULL, event_date TEXT NOT NULL)");
        db.execSQL("CREATE INDEX idx_history_date ON mission_history(event_date DESC)");
        db.execSQL("CREATE TABLE active_days (day TEXT PRIMARY KEY)");
        db.execSQL("CREATE TABLE achievements (badge_id TEXT PRIMARY KEY, earned_at TEXT NOT NULL)");
        db.execSQL("CREATE TABLE mood_entries (entry_id INTEGER PRIMARY KEY AUTOINCREMENT, mood_value INTEGER NOT NULL, mood_label TEXT NOT NULL, note TEXT, event_date TEXT NOT NULL)");
        db.execSQL("CREATE INDEX idx_mood_date ON mood_entries(event_date DESC)");
        db.execSQL("CREATE TABLE group_challenges (challenge_id TEXT PRIMARY KEY, title TEXT NOT NULL, code TEXT NOT NULL, note TEXT, created_at TEXT NOT NULL, payload_json TEXT NOT NULL)");
        db.execSQL("CREATE TABLE custom_missions (mission_id TEXT PRIMARY KEY, title TEXT NOT NULL, xp INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1, payload_json TEXT NOT NULL)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS mood_entries (entry_id INTEGER PRIMARY KEY AUTOINCREMENT, mood_value INTEGER NOT NULL, mood_label TEXT NOT NULL, note TEXT, event_date TEXT NOT NULL)");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_mood_date ON mood_entries(event_date DESC)");
            db.execSQL("CREATE TABLE IF NOT EXISTS group_challenges (challenge_id TEXT PRIMARY KEY, title TEXT NOT NULL, code TEXT NOT NULL, note TEXT, created_at TEXT NOT NULL, payload_json TEXT NOT NULL)");
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE profiles ADD COLUMN avatar_emoji TEXT NOT NULL DEFAULT '🥑'");
            db.execSQL("ALTER TABLE profiles ADD COLUMN bio TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE progress ADD COLUMN coins INTEGER NOT NULL DEFAULT 0");
            db.execSQL("CREATE TABLE IF NOT EXISTS custom_missions (mission_id TEXT PRIMARY KEY, title TEXT NOT NULL, xp INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1, payload_json TEXT NOT NULL)");
        }
    }

    public synchronized String loadState() {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.rawQuery("SELECT state_json FROM app_state WHERE id=1", null)) {
            return cursor.moveToFirst() ? cursor.getString(0) : null;
        }
    }

    public synchronized void saveState(String json) {
        if (json == null || json.trim().isEmpty()) return;
        final JSONObject state;
        try { state = new JSONObject(json); }
        catch (JSONException ignored) { return; }

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            String now = Instant.now().toString();
            String name = state.optString("name", "");
            String career = state.optString("career", "Ingeniería Mecatrónica");
            String cohort = state.optString("cohort", "Primer ciclo");
            String createdAt = state.optString("createdAt", now);
            String lastActive = state.isNull("lastActive") ? null : state.optString("lastActive", null);

            ContentValues profile = new ContentValues();
            profile.put("id", 1); profile.put("name", name); profile.put("career", career);
            profile.put("cohort", cohort); profile.put("created_at", createdAt);
            profile.put("avatar_emoji", state.optString("avatarEmoji", "🥑"));
            profile.put("bio", state.optString("bio", ""));
            if (lastActive == null) profile.putNull("last_active"); else profile.put("last_active", lastActive);
            db.insertWithOnConflict("profiles", null, profile, SQLiteDatabase.CONFLICT_REPLACE);

            ContentValues progress = new ContentValues();
            progress.put("id", 1); progress.put("xp", state.optInt("xp", 0));
            progress.put("coins", state.optInt("coins", 0));
            if (lastActive == null) progress.putNull("last_active"); else progress.put("last_active", lastActive);
            db.insertWithOnConflict("progress", null, progress, SQLiteDatabase.CONFLICT_REPLACE);

            JSONArray history = state.optJSONArray("history");
            Map<String, JSONObject> historyByMission = new HashMap<>();
            db.delete("mission_history", null, null);
            if (history != null) {
                for (int i = 0; i < history.length(); i++) {
                    JSONObject entry = history.optJSONObject(i);
                    if (entry == null) continue;
                    String missionId = entry.optString("id", "");
                    if (!missionId.isEmpty()) historyByMission.put(missionId, entry);
                    ContentValues item = new ContentValues();
                    item.put("mission_id", missionId);
                    item.put("title", entry.optString("title", "Misión"));
                    item.put("xp", entry.optInt("xp", 0));
                    item.put("event_date", entry.optString("date", now));
                    db.insert("mission_history", null, item);
                }
            }

            JSONArray completed = state.optJSONArray("completed");
            JSONObject reflections = state.optJSONObject("reflections");
            Set<String> ids = new HashSet<>();
            db.delete("completed_missions", null, null);
            if (completed != null) {
                for (int i = 0; i < completed.length(); i++) {
                    String id = completed.optString(i, "");
                    if (id.isEmpty()) continue;
                    ids.add(id);
                    JSONObject h = historyByMission.get(id);
                    ContentValues item = new ContentValues();
                    item.put("mission_id", id);
                    item.put("title", h == null ? "Misión " + id : h.optString("title", "Misión " + id));
                    item.put("xp", h == null ? 0 : h.optInt("xp", 0));
                    item.put("reflection", reflections == null ? "" : reflections.optString(id, ""));
                    item.put("completed_at", h == null ? now : h.optString("date", now));
                    db.insert("completed_missions", null, item);
                }
            }

            db.delete("active_days", null, null);
            JSONArray activeDays = state.optJSONArray("activeDays");
            if (activeDays != null) {
                for (int i = 0; i < activeDays.length(); i++) {
                    String day = activeDays.optString(i, "");
                    if (day.isEmpty()) continue;
                    ContentValues item = new ContentValues(); item.put("day", day);
                    db.insertWithOnConflict("active_days", null, item, SQLiteDatabase.CONFLICT_IGNORE);
                }
            }

            // Diario emocional: se guarda únicamente en este dispositivo.
            db.delete("mood_entries", null, null);
            JSONArray moodLog = state.optJSONArray("moodLog");
            if (moodLog != null) {
                for (int i = 0; i < moodLog.length(); i++) {
                    JSONObject entry = moodLog.optJSONObject(i);
                    if (entry == null) continue;
                    ContentValues item = new ContentValues();
                    item.put("mood_value", entry.optInt("value", 3));
                    item.put("mood_label", entry.optString("label", "Sin etiqueta"));
                    item.put("note", entry.optString("note", ""));
                    item.put("event_date", entry.optString("date", now));
                    db.insert("mood_entries", null, item);
                }
            }

            // Misiones personalizadas creadas desde el panel local.
            db.delete("custom_missions", null, null);
            JSONArray customMissions = state.optJSONArray("customMissions");
            if (customMissions != null) {
                for (int i = 0; i < customMissions.length(); i++) {
                    JSONObject entry = customMissions.optJSONObject(i);
                    if (entry == null) continue;
                    ContentValues item = new ContentValues();
                    item.put("mission_id", entry.optString("id", ""));
                    item.put("title", entry.optString("title", "Misión personalizada"));
                    item.put("xp", entry.optInt("xp", 0));
                    item.put("active", entry.optBoolean("active", true) ? 1 : 0);
                    item.put("payload_json", entry.toString());
                    db.insertWithOnConflict("custom_missions", null, item, SQLiteDatabase.CONFLICT_REPLACE);
                }
            }

            // Retos de equipo coordinados localmente; no existe sincronización remota.
            db.delete("group_challenges", null, null);
            JSONArray groups = state.optJSONArray("groupChallenges");
            if (groups != null) {
                for (int i = 0; i < groups.length(); i++) {
                    JSONObject entry = groups.optJSONObject(i);
                    if (entry == null) continue;
                    ContentValues item = new ContentValues();
                    item.put("challenge_id", entry.optString("id", ""));
                    item.put("title", entry.optString("title", "Reto de equipo"));
                    item.put("code", entry.optString("code", ""));
                    item.put("note", entry.optString("note", ""));
                    item.put("created_at", entry.optString("createdAt", now));
                    item.put("payload_json", entry.toString());
                    db.insertWithOnConflict("group_challenges", null, item, SQLiteDatabase.CONFLICT_REPLACE);
                }
            }

            syncAchievements(db, ids, now);
            ContentValues snapshot = new ContentValues();
            snapshot.put("id", 1); snapshot.put("state_json", state.toString()); snapshot.put("saved_at", now);
            db.insertWithOnConflict("app_state", null, snapshot, SQLiteDatabase.CONFLICT_REPLACE);
            db.setTransactionSuccessful();
        } catch (Exception ignored) {
            // La transacción se revierte; el estado anterior permanece intacto.
        } finally {
            db.endTransaction();
        }
    }

    private void syncAchievements(SQLiteDatabase db, Set<String> completed, String now) {
        Set<String> earned = new HashSet<>();
        int count = completed.size();
        int baseCount = 0;
        for (String id : completed) if (id.matches("\\d{2}")) baseCount++;
        if (count >= 1) earned.add("first");
        if (count >= 2) earned.add("explorer");
        if (completed.contains("03")) earned.add("curious");
        if (completed.contains("04")) earned.add("team");
        if (completed.contains("05")) earned.add("share");
        if (count >= 4) earned.add("connector");
        if (baseCount >= 12) earned.add("all");
        if (completed.contains("07")) earned.add("coffee");
        if (completed.contains("11")) earned.add("curious-campus");
        if (completed.contains("09")) earned.add("talent");
        if (completed.contains("10")) earned.add("study-buddy");
        if (completed.contains("12")) earned.add("planner");
        db.delete("achievements", null, null);
        for (String id : earned) {
            ContentValues v = new ContentValues(); v.put("badge_id", id); v.put("earned_at", now);
            db.insertWithOnConflict("achievements", null, v, SQLiteDatabase.CONFLICT_IGNORE);
        }
    }
}

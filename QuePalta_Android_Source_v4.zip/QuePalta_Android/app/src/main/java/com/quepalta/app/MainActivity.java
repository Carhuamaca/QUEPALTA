package com.quepalta.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CAMERA = 431;
    private static final int REQUEST_SCAN = 432;
    private static final int REQUEST_EXPORT = 433;
    private WebView webView;
    private QuePaltaDatabase database;
    private boolean cameraPermissionPending = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(27, 58, 48));
        window.setNavigationBarColor(Color.rgb(246, 242, 231));
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        database = new QuePaltaDatabase(this);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(246, 242, 231));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        webView.addJavascriptInterface(new QuePaltaBridge(), "QuePaltaDB");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private final class QuePaltaBridge {
        @JavascriptInterface public boolean isNativeApp() { return true; }
        @JavascriptInterface public String loadState() { return database.loadState(); }
        @JavascriptInterface public void saveState(String json) { database.saveState(json); }
        @JavascriptInterface public void scanQr() { runOnUiThread(() -> requestQrScan()); }
        @JavascriptInterface public void exportProgress(String json) { runOnUiThread(() -> saveProgressFile(json)); }
        @JavascriptInterface public void shareText(String text) { runOnUiThread(() -> shareTextExternally(text)); }
        @JavascriptInterface public void openUrl(String url) { runOnUiThread(() -> openExternalUrl(url)); }
    }


    private void shareTextExternally(String text) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
        startActivity(Intent.createChooser(intent, "Compartir reto de Que Palta"));
    }

    private void openExternalUrl(String url) {
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) {
            Toast.makeText(this, "Enlace no válido.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir el enlace.", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestQrScan() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermissionPending = true;
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
            return;
        }
        launchScanner();
    }

    private void launchScanner() {
        cameraPermissionPending = false;
        startActivityForResult(new Intent(this, ScanActivity.class), REQUEST_SCAN);
    }

    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA && cameraPermissionPending) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchScanner();
            else {
                notifyJsCancelled();
                Toast.makeText(this, "Activa el permiso de cámara para escanear códigos QR.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void saveProgressFile(String json) {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "que-palta-mi-progreso.json");
        intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
        pendingExportJson = json;
        startActivityForResult(intent, REQUEST_EXPORT);
    }

    private String pendingExportJson;

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingExportJson != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new IllegalStateException("No se pudo abrir el archivo de destino.");
                    output.write(pendingExportJson.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Copia de progreso guardada.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo guardar la copia.", Toast.LENGTH_LONG).show();
                }
            }
            pendingExportJson = null;
            return;
        }
        if (requestCode != REQUEST_SCAN || webView == null) return;
        if (resultCode == RESULT_OK && data != null) {
            String value = data.getStringExtra(ScanActivity.EXTRA_QR_VALUE);
            if (value != null) {
                String safe = JSONObject.quote(value);
                webView.evaluateJavascript("window.onNativeQrResult && window.onNativeQrResult(" + safe + ")", null);
            } else notifyJsCancelled();
        } else notifyJsCancelled();
    }

    private void notifyJsCancelled() {
        if (webView != null) webView.evaluateJavascript("window.onNativeQrCancelled && window.onNativeQrCancelled()", null);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("QuePaltaDB");
            webView.destroy();
            webView = null;
        }
        if (database != null) database.close();
        super.onDestroy();
    }
}

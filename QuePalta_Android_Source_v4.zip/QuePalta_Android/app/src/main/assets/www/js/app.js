(() => {
  'use strict';
  const STORE_KEY = 'que_palta_v2';
  const missions = [
    {id:'01', title:'Rompe el hielo', category:'Primer acercamiento', level:'Suave', xp:50, icon:'☀', tone:'teal', zone:'Rotonda', description:'Un hola puede cambiar tu día. Acércate a alguien que todavía no conoces y comienza con una pregunta sencilla.', objective:'Iniciar una conversación breve sin exigirte que sea perfecta.', steps:['Busca un momento tranquilo antes o después de clase.','Saluda a un compañero que aún no conozcas.','Pregúntale su nombre o qué curso lleva.'], reflection:'¿Cómo te sentiste al dar el primer paso?', unlock:0},
    {id:'02', title:'Encuentra tu conexión', category:'Explora el campus', level:'Suave', xp:60, icon:'⌖', tone:'orange', zone:'Punto de encuentro', description:'Descubre un espacio del campus y encuentra a alguien con quien compartir una recomendación o dato útil.', objective:'Usar el entorno universitario como punto de partida para conversar.', steps:['Dirígete a un punto de encuentro autorizado.','Escanea el QR de la estación o ingresa el código de prueba.','Conversa con alguien sobre un lugar útil del campus.'], reflection:'¿Qué descubriste de otra persona o del campus?', unlock:0},
    {id:'03', title:'Pregunta sin palta', category:'Pedir ayuda', level:'Intermedio', xp:70, icon:'💬', tone:'green', zone:'Aulas', description:'Hacer una pregunta también es participar. Pide una aclaración sobre una indicación, tarea o curso.', objective:'Practicar la comunicación y reducir el temor a preguntar.', steps:['Piensa en una duda real de una clase.','Pregúntale a un compañero o docente en el momento adecuado.','Agradece la orientación recibida.'], reflection:'¿Qué cambió después de preguntar?', unlock:0},
    {id:'04', title:'Arma tu mini equipo', category:'Trabajo colaborativo', level:'Intermedio', xp:90, icon:'♧', tone:'purple', zone:'Biblioteca', description:'Invita a una o dos personas a revisar una actividad o intercambiar ideas durante unos minutos.', objective:'Dar un paso hacia la colaboración con compañeros nuevos.', steps:['Identifica una actividad o tema que puedan conversar.','Invita a alguien que todavía no sea parte de tu círculo.','Compartan una idea o resuelvan una duda.'], reflection:'¿Qué aportó cada persona al intercambio?', unlock:50},
    {id:'05', title:'Una recomendación va', category:'Compartir experiencias', level:'Intermedio', xp:100, icon:'✧', tone:'blue', zone:'Cafetería', description:'Comparte un consejo que te habría servido al comenzar la universidad y escucha el de otra persona.', objective:'Crear apoyo mutuo entre estudiantes que están adaptándose.', steps:['Piensa en algo que aprendiste desde que ingresaste.','Compártelo con un compañero.','Escucha una recomendación y guárdala para tu semana.'], reflection:'¿Qué consejo te gustaría recordar?', unlock:110},
    {id:'06', title:'Conexión en equipo', category:'Integración', level:'Desafío', xp:130, icon:'✦', tone:'pink', zone:'Zona de encuentro', description:'Participa en una actividad breve con dos o más compañeros con quienes aún no hayas trabajado.', objective:'Llevar la confianza construida a una experiencia de colaboración.', steps:['Propón una actividad breve o una pregunta para conversar.','Invita a compañeros de distintos grupos.','Escuchen las ideas y acuerden un pequeño resultado común.'], reflection:'¿Qué hizo que el grupo pudiera colaborar?', unlock:200}
  ];
  missions.push(
    {id:'07', title:'Un café sin apuro', category:'Conversación cotidiana', level:'Intermedio', xp:75, icon:'☕', tone:'orange', zone:'Cafetería del pabellón L o K', description:'Comparte una pausa con alguien de clase. No necesitas hablar de todo: pueden comentar un curso, una canción o cómo va la semana.', objective:'Generar un momento cotidiano de conversación sin presión.', steps:['Elige a alguien con quien hayas conversado antes.','Propón tomar algo o sentarse unos minutos en un espacio común.','Escucha y comparte algo de tu semana.'], reflection:'¿Qué hizo que la conversación se sintiera cómoda?', unlock:100},
    {id:'08', title:'Encuentra tu gente', category:'Participación', level:'Intermedio', xp:85, icon:'✺', tone:'green', zone:'Rotonda o zona de encuentro', description:'Acércate a una actividad, taller o grupo que te llame la atención. Puedes participar solo como observador al comienzo.', objective:'Conocer espacios donde coincidan intereses.', steps:['Piensa en una actividad que te gustaría probar.','Pregunta dónde puedes encontrar información o cuándo se reúnen.','Da un primer paso: observa, pregunta o participa.'], reflection:'¿Qué actividad te gustaría volver a visitar?', unlock:100},
    {id:'09', title:'Comparte algo tuyo', category:'Confianza', level:'Intermedio', xp:90, icon:'✧', tone:'purple', zone:'Aulas o biblioteca', description:'Todos tenemos algo que aportar. Comparte un truco de estudio, una herramienta o un tema que te guste.', objective:'Reconocer que también tienes algo valioso que ofrecer.', steps:['Elige un dato, herramienta o habilidad que conozcas.','Compártelo con uno o dos compañeros.','Pregunta qué recurso usan ellos.'], reflection:'¿Cómo fue compartir algo que sabes?', unlock:150},
    {id:'10', title:'Estudiemos en dupla', category:'Apoyo académico', level:'Desafío', xp:110, icon:'⌘', tone:'blue', zone:'Biblioteca · Pabellón I', description:'Propón repasar un tema con otro estudiante. La meta no es saberlo todo, sino aprender juntos.', objective:'Construir un vínculo a través del apoyo académico.', steps:['Escoge un tema de una clase que estés llevando.','Invita a un compañero a repasar durante 15 minutos.','Cada uno explica una idea o pregunta que tenga.'], reflection:'¿Qué aprendiste de estudiar acompañado?', unlock:220},
    {id:'11', title:'Conoce una nueva ruta', category:'Explora el campus', level:'Suave', xp:65, icon:'⌖', tone:'teal', zone:'Campus Monterrico', description:'Ubica un servicio que todavía no conozcas. Explorar el campus también ayuda a sentirlo más familiar.', objective:'Reconocer espacios útiles para la vida universitaria.', steps:['Elige un servicio del mapa del campus.','Ubica el pabellón o pregunta cómo llegar.','Guarda el lugar para tu próxima visita.'], reflection:'¿Qué espacio te gustaría usar más?', unlock:0},
    {id:'12', title:'Propón un plan sencillo', category:'Integración', level:'Desafío', xp:140, icon:'✦', tone:'pink', zone:'Espacio común', description:'Da el siguiente paso: invita a dos compañeros a realizar algo sencillo, como almorzar, repasar o recorrer el campus.', objective:'Pasar de una conversación a una actividad compartida.', steps:['Piensa en un plan simple y de poca duración.','Invita a dos compañeros y deja que propongan alternativas.','Acuerden un momento que les funcione a todos.'], reflection:'¿Qué te gustaría repetir con este grupo?', unlock:300}
  );
  const badgeCatalog = [
    {id:'first', title:'Primer hola', desc:'Completaste tu primera misión.', icon:'👋', test:s=>s.completed.length>=1},
    {id:'explorer', title:'Explorador', desc:'Descubriste dos misiones.', icon:'🧭', test:s=>s.completed.length>=2},
    {id:'curious', title:'Sin miedo a preguntar', desc:'Probaste una misión de comunicación.', icon:'💬', test:s=>s.completed.includes('03')},
    {id:'team', title:'Modo equipo', desc:'Te sumaste a un reto colaborativo.', icon:'🤝', test:s=>s.completed.includes('04')},
    {id:'share', title:'Buena onda', desc:'Compartiste una recomendación.', icon:'✨', test:s=>s.completed.includes('05')},
    {id:'connector', title:'Conector', desc:'Completaste cuatro misiones.', icon:'🔗', test:s=>s.completed.length>=4},
    {id:'all', title:'Palta legendaria', desc:'Completaste las doce misiones base.', icon:'🥑', test:s=>s.completed.filter(id=>/^\d{2}$/.test(id)).length>=12},
    {id:'coffee', title:'Pausa compartida', desc:'Compartiste una pausa con alguien.', icon:'☕', test:s=>s.completed.includes('07')},
    {id:'curious-campus', title:'Campus conocido', desc:'Exploraste nuevos espacios.', icon:'🗺️', test:s=>s.completed.includes('11')},
    {id:'talent', title:'Algo que aportar', desc:'Compartiste algo que sabes.', icon:'💡', test:s=>s.completed.includes('09')},
    {id:'study-buddy', title:'Dúo de estudio', desc:'Repasaste con otra persona.', icon:'📚', test:s=>s.completed.includes('10')},
    {id:'planner', title:'Plan en marcha', desc:'Propusiste una actividad grupal.', icon:'🧩', test:s=>s.completed.includes('12')}
  ];
  const quotes = [
    'A veces la primera conversación empieza con una pregunta bastante simple.',
    'No hace falta caerle bien a todo el mundo. Basta con encontrar tu gente.',
    'Llegar a un lugar nuevo toma tiempo. No vas tarde.',
    'Un compañero de clase también puede convertirse en alguien de confianza.',
    'No necesitas tener algo brillante que decir para empezar a conversar.'
  ];
  let state = loadState();
  if (Array.isArray(state.customMissions)) missions.push(...state.customMissions.filter(m => m && m.id && m.title));
  let activeFilter = 'all';
  let activeMissionCategory = 'all';
  let missionSearchText = '';
  let selectedMoodEntryId = null;
  let scannerStream = null;
  let scannerTimer = null;
  let selectedFeeling = '';
  let pendingMission = null;
  const $ = (id) => document.getElementById(id);
  const esc = (str) => String(str ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function defaultState(){ return {name:'', career:'Ingeniería Mecatrónica', cohort:'Primer ciclo', xp:0, coins:0, avatarEmoji:'🥑', bio:'Dando un paso a la vez.', completed:[], history:[], reflections:{}, moodLog:[], groupChallenges:[], customMissions:[], preferences:{comfortableText:false,reduceMotion:false}, lastActive:null, activeDays:[], createdAt:new Date().toISOString()}; }
  function loadState(){
    try {
      // En Android, el origen de verdad es SQLite. En navegador se conserva localStorage.
      const native = window.QuePaltaDB && window.QuePaltaDB.isNativeApp && window.QuePaltaDB.isNativeApp();
      const raw = native ? (window.QuePaltaDB.loadState() || localStorage.getItem(STORE_KEY)) : localStorage.getItem(STORE_KEY);
      if(!raw) return defaultState();
      const loaded={...defaultState(),...JSON.parse(raw)};
      loaded.preferences={...defaultState().preferences,...(loaded.preferences||{})};
      loaded.moodLog=Array.isArray(loaded.moodLog)?loaded.moodLog:[];
      loaded.groupChallenges=Array.isArray(loaded.groupChallenges)?loaded.groupChallenges:[];
      return loaded;
    } catch(e){ return defaultState(); }
  }
  function saveState(){
    const raw = JSON.stringify(state);
    try {
      if(window.QuePaltaDB && window.QuePaltaDB.isNativeApp && window.QuePaltaDB.isNativeApp()) window.QuePaltaDB.saveState(raw);
      localStorage.setItem(STORE_KEY,raw);
    } catch(e){ console.warn('No se pudo guardar el progreso',e); }
  }
  function levelInfo(){ const levels=[{min:0,title:'Explorador'},{min:100,title:'Conector'},{min:220,title:'Compañero'},{min:380,title:'Integrador'},{min:570,title:'Leyenda Que Palta'}]; let index=0; levels.forEach((l,i)=>{if(state.xp>=l.min)index=i;}); const current=levels[index], next=levels[index+1]; return {number:index+1,title:current.title,min:current.min,next:next?next.min:state.xp,progress:next?Math.min(100,Math.round((state.xp-current.min)/(next.min-current.min)*100)):100}; }
  function unlocked(m){ return state.xp>=m.unlock || m.unlock===0; }
  function completed(m){ return state.completed.includes(m.id); }
  function awardBadges(){ return badgeCatalog.filter(b=>b.test(state)); }
  function localDateKey(d=new Date()){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
  function recordActiveDay(){ const today=localDateKey(); if(!state.activeDays.includes(today)){state.activeDays.push(today);state.activeDays=state.activeDays.slice(-45);saveState();} state.lastActive=today; }
  function streak(){ if(!state.activeDays.length)return 0; const set=new Set(state.activeDays); let count=0; let d=new Date(); while(set.has(localDateKey(d))){count++;d.setDate(d.getDate()-1);} if(!count){const y=new Date();y.setDate(y.getDate()-1);if(set.has(localDateKey(y)))count=1;} return count; }
  function showView(view){ stopScanner(); document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id===`view-${view}`)); document.querySelectorAll('[data-view]').forEach(x=>x.classList.toggle('active',x.dataset.view===view)); const label={home:'Inicio',missions:'Misiones',map:'Mapa del campus',scanner:'Escanear QR',profile:'Mi perfil',about:'Sobre Que Palta',mood:'Diario emocional',community:'Retos en equipo',admin:'Administración local'}[view]||'Inicio'; $('crumbLabel').textContent=label; $('sidebar').classList.remove('mobile-open'); window.scrollTo({top:0,behavior:'smooth'}); if(view==='map')renderMap(); if(view==='profile'){renderProfile();applyPreferences();} if(view==='missions')renderMissions();if(view==='mood')renderMood();if(view==='community')renderCommunity();if(view==='admin')renderAdmin(); }
  function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),2700);}
  function openModal(html){$('modalContent').innerHTML=html;$('modalBackdrop').hidden=false;document.body.style.overflow='hidden';}
  function closeModal(){ $('modalBackdrop').hidden=true;document.body.style.overflow='';$('modalClose').style.display='';pendingMission=null;selectedFeeling=''; }
  function applyPreferences(){
    const prefs=state.preferences||{};
    document.body.classList.toggle('pref-comfortable',!!prefs.comfortableText);
    document.body.classList.toggle('pref-calm',!!prefs.reduceMotion);
    if($('comfortableText'))$('comfortableText').checked=!!prefs.comfortableText;
    if($('reduceMotion'))$('reduceMotion').checked=!!prefs.reduceMotion;
  }
  function mascotMessage(){
    const count=state.completed.length;
    if(count===0)return '¿Primera semana? Tranqui. Mira una misión y elige la que te quede cómoda.';
    if(count<3)return 'Ya empezaste. No hay que apurarse: sigue a tu manera.';
    if(count<7)return 'Parece que ya vas ubicando tu lugar. Qué bueno.';
    return 'Ya tienes varias historias de campus. Guarda las que te hagan bien.';
  }
  function cheerMascot(message){
    const line=$('mascotLine');
    const button=$('mascotBtn');
    if(line)line.textContent=message||mascotMessage();
    if(button){button.classList.remove('mascot-pop');void button.offsetWidth;button.classList.add('mascot-pop');}
  }
  function populateMissionCategories(){
    const select=$('missionCategory'); if(!select)return;
    const categories=[...new Set(missions.filter(m=>m.active!==false).map(m=>m.category).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'es'));
    const current=activeMissionCategory;
    select.innerHTML='<option value="all">Todos los temas</option>'+categories.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');
    select.value=categories.includes(current)?current:'all';
  }
  function render(){ applyPreferences(); populateMissionCategories(); if(!state.name){welcomeModal();} $('welcomeName').textContent=state.name||'amigo';$('avatarInitial').textContent=state.avatarEmoji||((state.name||'Q').trim().charAt(0).toUpperCase());$('todayDate').textContent=new Intl.DateTimeFormat('es-PE',{weekday:'long',day:'numeric',month:'long'}).format(new Date());$('streakTop').textContent=streak();$('streakCount').textContent=streak();$('completedCount').textContent=state.completed.length;$('badgeCount').textContent=awardBadges().length;$('missionProgress').textContent=`${state.completed.length}/${missions.length}`;$('allCount').textContent=String(missions.length); const li=levelInfo();$('levelBadge').textContent=`NIVEL ${li.number}`;$('levelBadgeCard').textContent=`NIVEL ${li.number}`;$('levelNumber').textContent=String(li.number).padStart(2,'0');$('levelTitle').textContent=li.title;$('xpValue').textContent=state.xp;$('xpNext').textContent=li.next;$('xpBar').style.width=li.progress+'%';$('xpPercent').textContent=li.progress+'%';$('xpHint').textContent=li.next===state.xp?'¡Has alcanzado el nivel máximo!':`${li.next-state.xp} XP para el siguiente nivel`;$('dailyQuote').textContent=quotes[new Date().getDate()%quotes.length];$('totalMissionCount').textContent=missions.length;$('coinsValue').textContent=state.coins||0;$('mascotLine').textContent=mascotMessage();renderNextMission();renderWeek();renderMissions();renderMap(); }
  function renderNextMission(){const m=missions.find(x=>x.active!==false&&!completed(x)&&unlocked(x))||missions.find(x=>x.active!==false&&!completed(x))||missions[0];window.nextMissionId=m.id;$('todayTag').textContent=`RETO #${m.id} · ${m.category.toUpperCase()}`;$('heroTitle').innerHTML=m.title==='Rompe el hielo'?'Empieza con un<br>hola.':esc(m.title).replace(' ','<br>');$('heroDescription').textContent=m.description;$('heroMissionMeta').textContent=`${m.level} · ${m.xp} XP · ${m.zone}`;$('todayMissionBtn').onclick=()=>missionModal(m.id);$('nextMissionCard').innerHTML=`<div class="feature-top"><span class="mission-num">MISIÓN ${m.id} · ${esc(m.category.toUpperCase())}</span><span class="mission-status">${completed(m)?'Completada':'A tu alcance'}</span></div><h3>${esc(m.title)}</h3><p>${esc(m.description)}</p><div class="feature-foot"><span class="xp-chip">✦ ${m.xp} XP</span><button class="btn btn-primary" data-open-mission="${m.id}">Ver misión →</button></div>`; }
  function renderWeek(){const days=['L','M','X','J','V','S','D'];const today=(new Date().getDay()+6)%7;const html=days.map((d,i)=>{const date=new Date();date.setDate(date.getDate()-((today-i+7)%7));const iso=localDateKey(date);const done=state.activeDays.includes(iso);return `<div class="day-cell"><span>${d}</span><span class="day-dot ${done?'done':i===today?'today':''}">${done?'✓':date.getDate()}</span></div>`}).join('');$('weekDays').innerHTML=html; }
  function renderMissions(){
    const grid=$('missionGrid'); if(!grid)return;
    const needle=missionSearchText.trim().toLocaleLowerCase('es');
    const list=missions.filter(m=>{
      if(m.active===false)return false;
      const statusOK=activeFilter==='all'||(activeFilter==='available'&&!completed(m)&&unlocked(m))||(activeFilter==='completed'&&completed(m));
      const categoryOK=activeMissionCategory==='all'||m.category===activeMissionCategory;
      const haystack=[m.title,m.description,m.category,m.zone].join(' ').toLocaleLowerCase('es');
      return statusOK&&categoryOK&&(!needle||haystack.includes(needle));
    });
    grid.innerHTML=list.map(m=>{
      const done=completed(m),open=unlocked(m);
      const status=done?'Completada':open?'Disponible':`Se abre con ${m.unlock} XP`;
      return `<article class="mission-card ${done?'completed':''} ${!open?'locked':''}">
        <div class="mission-card-top"><span class="mission-symbol symbol-${esc(m.tone)}"><small>${esc(m.id)}</small></span><span class="difficulty">${esc(m.level.toUpperCase())}</span></div>
        <span class="mission-category">${esc(m.category)}</span>
        <h3>${esc(m.title)}</h3><p>${esc(m.description)}</p>
        <div class="mission-card-bottom"><div><strong>+${m.xp} XP</strong><small>${esc(status)}</small></div><button data-open-mission="${esc(m.id)}" ${!open&&!done?'disabled':''}>${done?'Ver avance':open?'Ver reto':'Bloqueada'}</button></div>
      </article>`;
    }).join('')||'<div class="empty-state mission-empty">No encontramos misiones con esos filtros. Prueba con otra palabra o vuelve a “Todas”.</div>';
    if($('allCount'))$('allCount').textContent=String(missions.filter(m=>m.active!==false).length);
  }

  const campusPlaces=[
    {id:'11',name:'Rotonda · Estar de alumnos',building:'Punto 11',mission:'01',detail:'Un espacio central para empezar una conversación.',type:'Encuentro',x:50,y:52},
    {id:'24',name:'Biblioteca · Pabellón I',building:'Punto 24',mission:'10',detail:'Salas de lectura y espacios para estudiar.',type:'Estudio',x:17,y:74},
    {id:'3',name:'Cafetería · Pabellón L',building:'Punto 3',mission:'07',detail:'Una pausa puede convertirse en una conversación.',type:'Comida',x:83,y:26},
    {id:'13',name:'Restaurant Kata · Pabellón G',building:'Punto 13',mission:'12',detail:'Un lugar para compartir un plan sencillo.',type:'Comida',x:87,y:67},
    {id:'27',name:'Cafetería · Pabellón K',building:'Punto 27',mission:'02',detail:'Otro punto para encontrarse y conversar.',type:'Comida',x:8,y:61},
    {id:'22',name:'Tópico',building:'Punto 22',mission:null,detail:'Servicio de atención de salud del campus.',type:'Servicio',x:8,y:86},
    {id:'18',name:'Aula Magna',building:'Punto 18',mission:'08',detail:'Espacio de actividades y encuentros.',type:'Actividad',x:34,y:79},
    {id:'17',name:'Pabellón A · Aulas',building:'Punto 17',mission:'03',detail:'Las clases también son una oportunidad para preguntar.',type:'Aulas',x:47,y:80}
  ];
  function renderMap(){
    const list=$('locationList'); if(!list)return;
    list.innerHTML=campusPlaces.map(l=>`<button class="location-item" data-campus-place="${l.id}"><span class="location-pin">${l.type==='Comida'?'☕':l.type==='Estudio'?'📚':l.type==='Servicio'?'✚':l.type==='Aulas'?'⌂':'✦'}</span><span><strong>${esc(l.name)}</strong><small>${esc(l.detail)}</small></span><em>→</em></button>`).join('');
    const layer=$('campusPinLayer');if(layer)layer.innerHTML=campusPlaces.map(p=>`<button class="campus-map-pin pin-${p.type==='Estudio'?'study':p.type==='Comida'?'food':p.type==='Servicio'?'service':'meet'}" style="left:${p.x}%;top:${p.y}%" data-campus-place="${p.id}" aria-label="${esc(p.name)}"><span>${p.id}</span></button>`).join('');
  }
  function openCampusPlace(id){const p=campusPlaces.find(x=>x.id===id);if(!p)return;const mission=p.mission?missions.find(m=>m.id===p.mission):null;openModal(`<span class="modal-kicker">CAMPUS MONTERRICO · ${esc(p.building)}</span><h2 id="modalTitle">${esc(p.name)}</h2><p>${esc(p.detail)}</p><div class="campus-meta"><span>${esc(p.type)}</span><span>${p.mission?'Reto sugerido #'+p.mission:'Punto de servicio'}</span></div><div class="modal-actions"><button class="btn btn-outline" id="campusMapClose">Cerrar</button>${mission?`<button class="btn btn-primary" id="campusMissionOpen">Ver misión</button>`:''}</div>`);$('campusMapClose').onclick=closeModal;if(mission)$('campusMissionOpen').onclick=()=>{closeModal();missionModal(mission.id);};}
  function renderProfile(){const li=levelInfo();$('profileName').textContent=state.name||'Estudiante';$('profileCareer').textContent=state.career+' · '+state.cohort;$('profileLevel').textContent=`NIVEL ${li.number} · ${li.title.toUpperCase()}`;$('profileXP').textContent=state.xp+' XP';$('profileAvatar').textContent=state.avatarEmoji||((state.name||'Q').trim().charAt(0).toUpperCase());$('profileBio').textContent=state.bio||'Dando un paso a la vez.';$('profileCoins').textContent=state.coins||0;$('statMission').textContent=state.completed.length;$('statBadges').textContent=awardBadges().length;$('statStreak').textContent=streak();$('badgeGrid').innerHTML=badgeCatalog.map(b=>{const got=b.test(state);return `<div class="achievement ${got?'earned':''}"><span class="medal">${b.icon}</span><strong>${b.title}</strong><small>${got?'Desbloqueada':b.desc}</small></div>`}).join('');$('moodSummary').textContent=state.moodLog?.length?`${state.moodLog.length} registros personales`:'Todavía no hay registros';$('activityList').innerHTML=state.history.length?state.history.slice(0,6).map(h=>`<div class="activity-entry"><span>✓</span><div><strong>${esc(h.title)}</strong><small>${new Date(h.date).toLocaleDateString('es-PE')} · +${h.xp} XP</small></div></div>`).join(''):'<div class="empty-state">Cuando completes tu primera misión, aparecerá aquí.</div>'; }
  function missionModal(id){
    const m=missions.find(x=>x.id===id); if(!m)return;
    if(m.active===false){toast('Esta misión está pausada en este dispositivo.');return;}
    selectedFeeling=''; pendingMission=id;
    const done=completed(m),open=unlocked(m);
    if(!open&&!done){toast('Completa otras misiones para desbloquear este reto.');return;}
    openModal(`<span class="modal-kicker">MISIÓN ${esc(m.id)} · ${esc(m.category.toUpperCase())}</span>
      <h2 id="modalTitle">${esc(m.title)}</h2><p>${esc(m.description)}</p>
      <div class="modal-reward"><strong>AL COMPLETARLA</strong><span>+${m.xp} XP</span></div>
      <div class="mission-objective"><span>LA IDEA</span><p>${esc(m.objective||'Dar un paso pequeño y a tu ritmo.')}</p></div>
      <p><strong class="modal-section-title">Una forma de hacerlo</strong></p>
      <div class="modal-steps">${m.steps.map((step,i)=>`<div class="modal-step"><span class="step-no">${String(i+1).padStart(2,'0')}</span><span>${esc(step)}</span></div>`).join('')}</div>
      ${done?`<div class="soft-callout"><span>✓</span><div><strong>Ya la marcaste como completada.</strong><p>${esc(state.reflections[id]||'Buen trabajo por atreverte a dar el paso.')}</p></div></div><div class="modal-actions"><button class="btn btn-dark" id="closeMissionBtn">Listo</button></div>`:
      `<div class="reflection-block"><p><strong class="modal-section-title">¿Cómo te fue?</strong> <small>Este paso es opcional.</small></p>
        <div class="mission-reflection">${['Me sentí cómodo','Tuve nervios','Me costó, pero lo hice','Me sorprendió'].map((f,i)=>`<button type="button" class="feeling-choice" data-feeling="${i}">${f}</button>`).join('')}</div>
        <button type="button" class="skip-reflection" data-feeling="skip">Prefiero no responder</button>
        <label class="form-label" for="missionNote">¿Quieres guardar algún detalle? (opcional)</label>
        <textarea class="input mission-note" id="missionNote" maxlength="240" placeholder="Una idea, algo que te gustó o que harías distinto…"></textarea>
      </div>
      <div class="modal-actions"><button class="btn btn-outline" id="cancelMissionBtn">Lo haré después</button><button class="btn btn-primary" id="completeMissionBtn">Marcar como hecha</button></div>`}`);
    document.querySelectorAll('[data-feeling]').forEach(b=>b.addEventListener('click',()=>{
      selectedFeeling=b.dataset.feeling==='skip'?'Prefiero no responder':b.textContent;
      document.querySelectorAll('[data-feeling]').forEach(x=>x.classList.toggle('selected',x===b));
    }));
    $('closeMissionBtn')?.addEventListener('click',closeModal);
    $('cancelMissionBtn')?.addEventListener('click',closeModal);
    $('completeMissionBtn')?.addEventListener('click',()=>completeMission(id));
  }
  function completeMission(id){
    const m=missions.find(x=>x.id===id); if(!m||completed(m))return;
    const oldLevel=levelInfo().number;
    const note=$('missionNote')?.value.trim()||'';
    const feeling=selectedFeeling||'Sin respuesta';
    const coins=Math.max(5,Math.round(m.xp/10));
    state.completed.push(id); state.xp+=m.xp; state.coins=(state.coins||0)+coins;
    state.reflections[id]=note?`${feeling}\n${note}`:feeling;
    state.history.unshift({id,title:m.title,xp:m.xp,date:new Date().toISOString()});
    recordActiveDay(); saveState(); closeModal(); render(); renderProfile();
    toast(`Misión guardada · +${m.xp} XP · +${coins} monedas`);
    const leveled=levelInfo().number>oldLevel;
    cheerMascot(leveled?'¡Subiste de nivel!':'Bien ahí. Un paso más.');
    if(window.confettiCelebration)window.confettiCelebration();
    if(leveled)toast('Nuevo nivel: '+levelInfo().title+'.');
  }

  function welcomeModal(){$('modalClose').style.display='none';openModal(`<div class="welcome-modal"><img class="welcome-modal-logo" src="assets/logo-que-palta.webp" alt="Que Palta"><span class="modal-kicker">QUÉ BUENO TENERTE POR AQUÍ</span><h2 id="modalTitle">Conocer gente lleva su tiempo.</h2><p>Aquí encontrarás ideas sencillas para conversar, recorrer el campus y conocer a tus compañeros. Tú eliges cuándo probarlas.</p><input class="input" id="welcomeInput" maxlength="28" placeholder="¿Cómo te llamas?" autocomplete="given-name"><label class="form-label">Carrera</label><select class="input" id="welcomeCareer"><option>Ingeniería Mecatrónica</option><option>Ingeniería Biomédica</option><option>Otra carrera</option></select><label class="form-label">Etapa</label><select class="input" id="welcomeCohort"><option>Primer ciclo</option><option>Segundo ciclo</option><option>Otro ciclo</option></select><button class="btn btn-primary" id="saveWelcome">Entrar a Que Palta <span>→</span></button><span class="privacy-small">Tu nombre y progreso se guardan solo en este dispositivo.</span></div>`);$('saveWelcome').addEventListener('click',()=>{const name=$('welcomeInput').value.trim();if(!name){$('welcomeInput').focus();toast('Escribe tu nombre para continuar.');return;}state.name=name;state.career=$('welcomeCareer')?.value||state.career;state.cohort=$('welcomeCohort')?.value||state.cohort;recordActiveDay();saveState();closeModal();render();toast(`¡Bienvenido, ${name}!`);});$('welcomeInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('saveWelcome').click();}); }
  function editProfile(){openModal(`<span class="modal-kicker">TU PERFIL</span><h2 id="modalTitle">Actualiza tus datos</h2><p>Solo se usan para personalizar tu experiencia en este dispositivo.</p><label class="form-label">Nombre</label><input class="input" id="editName" maxlength="28" value="${esc(state.name)}"><label class="form-label">Carrera</label><input class="input" id="editCareer" value="${esc(state.career)}"><label class="form-label">Etapa</label><input class="input" id="editCohort" value="${esc(state.cohort)}"><label class="form-label">Una frase sobre ti</label><input class="input" id="editBio" maxlength="70" value="${esc(state.bio||'')}"><label class="form-label">Tu avatar</label><div class="avatar-choices">${['🥑','🌱','🦋','🐸','🌞','🍊','🧩','🛸'].map(e=>`<button type="button" class="avatar-choice ${state.avatarEmoji===e?'selected':''}" data-avatar-choice="${e}">${e}</button>`).join('')}</div><div class="modal-actions"><button class="btn btn-outline" id="cancelEdit">Cancelar</button><button class="btn btn-primary" id="saveEdit">Guardar cambios</button></div>`);$('cancelEdit').onclick=closeModal;$('saveEdit').onclick=()=>{const n=$('editName').value.trim();if(!n){toast('El nombre no puede quedar vacío.');return;}state.name=n;state.career=$('editCareer').value.trim()||'Estudiante';state.cohort=$('editCohort').value.trim()||'Ingresante';state.bio=$('editBio').value.trim()||'Dando un paso a la vez.';saveState();closeModal();render();renderProfile();toast('Perfil actualizado.');}; }
  function parseQr(raw){const s=String(raw||'').trim().toUpperCase().replace(/\s/g,'');const custom=s.match(/QP\|CUSTOM\|(C[0-9A-Z]+)/);if(custom){return missions.find(m=>m.id===custom[1])||null;}let match=s.match(/(?:QP|QUEPALTA)\|MISION\|0?(\d{1,2})/);if(!match)match=s.match(/(?:QP|QUEPALTA)[-_ ]?0?(\d{1,2})/);if(match){const id=String(Number(match[1])).padStart(2,'0');return missions.find(m=>m.id===id)||null;}return null;}
  function handleQr(raw){const m=parseQr(raw);if(!m){toast('No reconocí ese código. Revisa que sea un QR de Que Palta.');return;}stopScanner();showView('missions');setTimeout(()=>missionModal(m.id),120);}
  async function startScanner(){if(window.QuePaltaDB && window.QuePaltaDB.isNativeApp && window.QuePaltaDB.isNativeApp()){ $('scannerStatus').textContent='Abriendo la cámara del celular…'; $('startScanBtn').disabled=true; window.QuePaltaDB.scanQr(); return; } if(!navigator.mediaDevices?.getUserMedia){$('scannerStatus').textContent='Este navegador no permite abrir la cámara. Usa el campo de código manual.';return;}if(!('BarcodeDetector' in window)){ $('scannerStatus').textContent='Este navegador no incluye lector QR integrado. Usa Chrome en Android o ingresa el código manualmente.';return;}try{const detector=new BarcodeDetector({formats:['qr_code']});scannerStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});const video=$('cameraVideo');video.srcObject=scannerStream;video.hidden=false;$('cameraPlaceholder').hidden=true;$('scanLine').hidden=false;await video.play();$('scannerStatus').textContent='Cámara activa. Centra el código QR dentro del recuadro.';$('startScanBtn').disabled=true;$('stopScanBtn').disabled=false;scannerTimer=setInterval(async()=>{try{if(video.readyState<2)return;const codes=await detector.detect(video);if(codes.length&&codes[0].rawValue)handleQr(codes[0].rawValue);}catch(e){}},450);}catch(err){$('scannerStatus').textContent=err.name==='NotAllowedError'?'No diste permiso a la cámara. Actívalo en el navegador o usa el código manual.':'No se pudo iniciar la cámara. Prueba con Chrome y una conexión segura.';}}
  window.onNativeQrResult = function(raw){ $('startScanBtn').disabled=false; $('scannerStatus').textContent='Código leído correctamente.'; handleQr(raw); };
  window.onNativeQrCancelled = function(){ $('startScanBtn').disabled=false; $('scannerStatus').textContent='Escaneo cancelado. Puedes intentarlo otra vez o escribir el código.'; };
  function stopScanner(){if(scannerTimer){clearInterval(scannerTimer);scannerTimer=null;}if(scannerStream){scannerStream.getTracks().forEach(t=>t.stop());scannerStream=null;}const v=$('cameraVideo');if(v){v.pause();v.srcObject=null;v.hidden=true;}if($('cameraPlaceholder'))$('cameraPlaceholder').hidden=false;if($('scanLine'))$('scanLine').hidden=true;if($('startScanBtn'))$('startScanBtn').disabled=false;if($('stopScanBtn'))$('stopScanBtn').disabled=true;}
  function openExternalCampusMap(){const url='https://www.upc.edu.pe/nosotros/pilares-estrategicos/resultados/documentos/CAMPUS%20UPC%20MONTERRICO_MAPA%20ACCESIBILIDAD.pdf';if(window.QuePaltaDB?.openUrl)window.QuePaltaDB.openUrl(url);else window.open(url,'_blank','noopener');}
  function renderMood(){
    const log=state.moodLog||[]; const latest=log.slice(0,12);
    $('moodSummaryCount').textContent=log.length;
    $('moodEntries').innerHTML=latest.length?latest.map(x=>{
      const key=String(x.id||x.date);
      const date=Number.isNaN(new Date(x.date).getTime())?'Fecha no disponible':new Date(x.date).toLocaleString('es-PE',{dateStyle:'medium',timeStyle:'short'});
      return `<article class="mood-entry"><span class="mood-face">${esc(x.emoji)}</span><div class="mood-entry-content"><strong>${esc(x.label)}</strong><small>${date}</small>${x.note?`<p>${esc(x.note)}</p>`:''}</div><button class="mood-delete" type="button" data-mood-delete="${esc(key)}" aria-label="Eliminar registro" title="Eliminar registro">×</button></article>`;
    }).join(''):'<div class="empty-state">Todavía no has guardado ningún registro. Puedes empezar cuando te sirva.</div>';
    const recent=log.slice(0,7);
    $('moodInsight').textContent=recent.length?`Has guardado ${recent.length} ${recent.length===1?'momento':'momentos'} recientes. Puedes volver a leerlos o borrar cualquiera cuando quieras.`:'Este espacio es privado y opcional. No intenta ponerle una etiqueta a lo que sientes.';
  }
  function deleteMoodEntry(key){
    const before=state.moodLog.length;
    state.moodLog=state.moodLog.filter(x=>String(x.id||x.date)!==String(key));
    if(state.moodLog.length===before)return;
    saveState(); renderMood(); renderProfile(); toast('Registro eliminado de este dispositivo.');
  }

  function openMoodCheckin(){selectedFeeling='';openModal(`<span class="modal-kicker">UN MOMENTO PARA TI</span><h2 id="modalTitle">¿Cómo te has sentido hoy?</h2><p>No hay respuestas buenas o malas. Este registro es privado y se guarda en este dispositivo.</p><div class="mood-choice-grid">${[{e:'😄',l:'Con energía',v:5},{e:'🙂',l:'Tranquilo',v:4},{e:'😐',l:'Normal',v:3},{e:'😟',l:'Nervioso',v:2},{e:'😔',l:'Bajoneado',v:1}].map(x=>`<button class="mood-choice" data-mood="${x.v}" data-label="${x.l}" data-emoji="${x.e}"><span>${x.e}</span><small>${x.l}</small></button>`).join('')}</div><label class="form-label">¿Quieres dejar una nota? (opcional)</label><textarea class="input mood-note" id="moodNote" maxlength="240" placeholder="Escribe lo que quieras recordar…"></textarea><div class="modal-actions"><button class="btn btn-outline" id="moodCancel">Ahora no</button><button class="btn btn-primary" id="moodConfirm" disabled>Guardar registro</button></div>`);document.querySelectorAll('[data-mood]').forEach(b=>b.onclick=()=>{selectedFeeling=b.dataset.mood;document.querySelectorAll('[data-mood]').forEach(x=>x.classList.toggle('selected',x===b));$('moodConfirm').disabled=false;});$('moodCancel').onclick=closeModal;$('moodConfirm').onclick=()=>{const pick=document.querySelector('[data-mood].selected');if(!pick)return;state.moodLog=state.moodLog||[];state.moodLog.unshift({id:'m'+Date.now().toString(36),value:Number(pick.dataset.mood),label:pick.dataset.label,emoji:pick.dataset.emoji,note:$('moodNote').value.trim(),date:new Date().toISOString()});state.moodLog=state.moodLog.slice(0,90);saveState();closeModal();renderMood();renderProfile();toast('Tu registro quedó guardado en este dispositivo.');};}
  function saveMoodCheckin(){openMoodCheckin();}
  function renderCommunity(){
    const list=state.groupChallenges||[];
    $('communityList').innerHTML=list.length?list.map(g=>{
      const meet=g.meetAt?new Date(g.meetAt):null;
      const meeting=meet&&!Number.isNaN(meet.getTime())?`<div class="group-meeting"><span>FECHA PROPUESTA</span><strong>${meet.toLocaleString('es-PE',{weekday:'short',day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}</strong></div>`:'';
      return `<article class="group-card"><div class="group-card-head"><div><span class="eyebrow">RETO DE EQUIPO · ${esc(g.code)}</span><h3>${esc(g.title)}</h3></div><span class="group-count">${g.members.length} ${g.members.length===1?'persona':'personas'}</span></div>${meeting}<p>${esc(g.note||'Un pequeño plan para encontrarse.')}</p><div class="group-members">${g.members.map(m=>`<label class="group-member ${g.done.includes(m)?'done':''}"><input type="checkbox" data-group-action="toggle" data-group-id="${esc(g.id)}" data-member="${esc(m)}" ${g.done.includes(m)?'checked':''}><span>${esc(m)}</span></label>`).join('')}</div><div class="group-progress"><span>${g.done.length}/${g.members.length} participaciones</span><div class="group-actions"><button class="text-link" data-group-action="share" data-group-id="${esc(g.id)}">Compartir ↗</button><button class="text-link group-remove" data-group-action="delete" data-group-id="${esc(g.id)}">Eliminar</button></div></div></article>`;
    }).join(''):'<div class="empty-state">Todavía no hay un plan guardado. Arma uno para estudiar, conversar o recorrer el campus.</div>';
  }
  function createGroupChallenge(){
    const title=$('groupTitle').value.trim();
    const members=$('groupMembers').value.split(',').map(x=>x.trim()).filter(Boolean);
    const note=$('groupNote').value.trim();
    const uniqueMembers=[...new Set(members.map(x=>x.replace(/\s+/g,' ')))];
    const meetAt=$('groupMeetAt')?.value||'';
    if(title.length<4){toast('Ponle un nombre un poco más claro al reto.');return;}
    if(uniqueMembers.length<2){toast('Agrega al menos dos participantes, separados por comas.');return;}
    if(uniqueMembers.some(x=>x.length>35)){toast('Cada nombre debe tener 35 caracteres como máximo.');return;}
    if(meetAt&&new Date(meetAt).getTime()<Date.now()-60000){toast('La fecha del encuentro debe ser futura.');return;}
    const id='g'+Date.now().toString(36); const code='QP-'+Math.random().toString(36).slice(2,7).toUpperCase();
    state.groupChallenges=state.groupChallenges||[];
    state.groupChallenges.unshift({id,code,title,note,members:uniqueMembers,done:[],meetAt,createdAt:new Date().toISOString()});
    saveState(); $('groupTitle').value='';$('groupMembers').value='';$('groupNote').value='';if($('groupMeetAt'))$('groupMeetAt').value='';renderCommunity();toast('Plan guardado. Puedes compartir los detalles con tu grupo.');
  }
  function groupAction(action,id,member){
    const g=(state.groupChallenges||[]).find(x=>x.id===id);if(!g)return;
    if(action==='toggle'){
      const checkbox=[...document.querySelectorAll('[data-group-action="toggle"]')].find(x=>x.dataset.groupId===id&&x.dataset.member===member);
      const checked=checkbox?.checked;
      if(checked&&!g.done.includes(member))g.done.push(member);else g.done=g.done.filter(x=>x!==member);
      saveState();renderCommunity();return;
    }
    if(action==='delete'){
      openModal(`<span class="modal-kicker">RETOS DE EQUIPO</span><h2 id="modalTitle">¿Eliminar este plan?</h2><p>Se borrará el reto “${esc(g.title)}” y su lista de participación de este dispositivo.</p><div class="modal-actions"><button class="btn btn-outline" id="keepGroup">Conservar</button><button class="btn btn-primary" id="confirmDeleteGroup">Eliminar plan</button></div>`);
      $('keepGroup').onclick=closeModal;$('confirmDeleteGroup').onclick=()=>{state.groupChallenges=state.groupChallenges.filter(x=>x.id!==id);saveState();closeModal();renderCommunity();toast('Plan eliminado.');};return;
    }
    if(action==='share'){
      const meet=g.meetAt?new Date(g.meetAt).toLocaleString('es-PE',{dateStyle:'medium',timeStyle:'short'}):'Por coordinar';
      const text=`Armemos este plan con Que Palta.\nActividad: ${g.title}\nQué haremos: ${g.note||'Lo coordinamos entre todos.'}\nCuándo: ${meet}\nParticipantes: ${g.members.join(', ')}\nCódigo: ${g.code}\nEsta invitación sirve para coordinar; el avance se registra en cada celular.`;
      if(window.QuePaltaDB?.shareText)window.QuePaltaDB.shareText(text);else if(navigator.share)navigator.share({title:'Plan de Que Palta',text}).catch(()=>{});else toast('Código del reto: '+g.code);
    }
  }

  function renderAdmin(){const custom=state.customMissions||[];$('adminMissionList').innerHTML=custom.length?custom.map(m=>`<div class="admin-mission"><div><strong>${esc(m.title)}</strong><small>${esc(m.id)} · ${m.xp} XP · ${m.active===false?'Pausada':'Activa'}</small></div><button class="btn btn-outline btn-small" data-admin-action="toggle" data-mission-id="${esc(m.id)}">${m.active===false?'Activar':'Pausar'}</button></div>`).join(''):'<div class="empty-state">Aún no hay misiones creadas por el administrador local.</div>';}
  function createCustomMission(){const title=$('adminTitle').value.trim();const desc=$('adminDescription').value.trim();const xp=Math.max(10,Math.min(250,Number($('adminXp').value)||50));if(title.length<4||desc.length<20){toast('Completa un título y una descripción un poco más detallada.');return;}const id='C'+Date.now().toString(36).toUpperCase().slice(-6);const m={id,title,description:desc,category:'Misión creada',level:'Personalizada',xp,icon:'✦',tone:'teal',zone:'Por definir',objective:'Crear una nueva oportunidad para conectar.',steps:['Lee el reto y elige un momento adecuado.','Realiza la actividad a tu ritmo.','Registra cómo te fue.'],reflection:'¿Cómo te sentiste al completar este reto?',unlock:0,active:true};state.customMissions=state.customMissions||[];state.customMissions.push(m);missions.push(m);saveState();$('adminTitle').value='';$('adminDescription').value='';$('adminXp').value='50';populateMissionCategories();renderAdmin();renderMissions();$('missionProgress').textContent=`${state.completed.length}/${missions.length}`;$('allCount').textContent=String(missions.length);toast('Misión local creada. Código: QP|CUSTOM|'+id);}
  function adminAction(action,id){const m=(state.customMissions||[]).find(x=>x.id===id);if(!m)return;if(action==='toggle'){m.active=m.active===false;saveState();renderAdmin();renderMissions();toast(m.active?'Misión activada.':'Misión pausada.');}}
  function exportProgress(){const content=JSON.stringify({app:'Que Palta',version:5,exportedAt:new Date().toISOString(),state},null,2);if(window.QuePaltaDB&&window.QuePaltaDB.isNativeApp&&window.QuePaltaDB.isNativeApp()){window.QuePaltaDB.exportProgress(content);return;}const blob=new Blob([content],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='que-palta-mi-progreso.json';a.click();URL.revokeObjectURL(url);toast('Copia de tu progreso descargada.');}
  function resetProgress(){openModal(`<span class="modal-kicker">CONFIRMAR ACCIÓN</span><h2 id="modalTitle">¿Reiniciar tu progreso?</h2><p>Se borrarán las misiones, XP, insignias y actividad guardada en este dispositivo. Esta acción no se puede deshacer.</p><div class="modal-actions"><button class="btn btn-outline" id="keepProgress">Conservar mi avance</button><button class="btn btn-primary" id="confirmReset">Reiniciar</button></div>`);$('keepProgress').onclick=closeModal;$('confirmReset').onclick=()=>{state=defaultState();for(let i=missions.length-1;i>=0;i--){if(String(missions[i].id).startsWith('C'))missions.splice(i,1);}saveState();closeModal();render();welcomeModal();toast('Progreso reiniciado.');};}
  function bindEvents(){
    document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.view)));
    document.querySelectorAll('[data-map-mission]').forEach(p=>p.addEventListener('click',()=>missionModal(p.dataset.mapMission)));
    document.addEventListener('click',e=>{
      const place=e.target.closest('[data-campus-place]'); if(place)openCampusPlace(place.dataset.campusPlace);
      const av=e.target.closest('[data-avatar-choice]'); if(av){state.avatarEmoji=av.dataset.avatarChoice;saveState();$('avatarInitial').textContent=state.avatarEmoji;document.querySelectorAll('[data-avatar-choice]').forEach(x=>x.classList.toggle('selected',x===av));}
      const m=e.target.closest('[data-open-mission]'); if(m)missionModal(m.dataset.openMission);
      const g=e.target.closest('[data-go]'); if(g)showView(g.dataset.go);
      const q=e.target.closest('[data-code]'); if(q){$('manualQr').value=q.dataset.code;handleQr(q.dataset.code);}
      const act=e.target.closest('[data-group-action="share"],[data-group-action="delete"]'); if(act)groupAction(act.dataset.groupAction,act.dataset.groupId,act.dataset.member);
      const am=e.target.closest('[data-admin-action]'); if(am)adminAction(am.dataset.adminAction,am.dataset.missionId);
    });
    // El cambio del checkbox se procesa en change para que el valor checked ya esté actualizado,
    // incluso cuando se toca el texto de la etiqueta en una pantalla táctil.
    document.addEventListener('change',e=>{const act=e.target.closest('[data-group-action="toggle"]');if(act)groupAction('toggle',act.dataset.groupId,act.dataset.member);});
    document.addEventListener('click',e=>{const b=e.target.closest('[data-mood-delete]');if(b)deleteMoodEntry(b.dataset.moodDelete);});
    $('missionFilters').addEventListener('click',e=>{const b=e.target.closest('[data-filter]');if(!b)return;activeFilter=b.dataset.filter;document.querySelectorAll('.filter-tab').forEach(x=>x.classList.toggle('active',x===b));renderMissions();});
    $('missionSearch')?.addEventListener('input',e=>{missionSearchText=e.target.value||'';renderMissions();});
    $('missionCategory')?.addEventListener('change',e=>{activeMissionCategory=e.target.value||'all';renderMissions();});
    $('comfortableText')?.addEventListener('change',e=>{state.preferences=state.preferences||{};state.preferences.comfortableText=e.target.checked;saveState();applyPreferences();});
    $('reduceMotion')?.addEventListener('change',e=>{state.preferences=state.preferences||{};state.preferences.reduceMotion=e.target.checked;saveState();applyPreferences();});
    $('modalClose').onclick=closeModal;$('modalBackdrop').addEventListener('click',e=>{if(e.target===$('modalBackdrop'))closeModal();});
    $('todayMissionBtn').onclick=()=>missionModal(window.nextMissionId||'01');$('avatarButton').onclick=editProfile;$('editProfileBtn').onclick=editProfile;
    $('startScanBtn').onclick=startScanner;$('stopScanBtn').onclick=stopScanner;$('manualScanBtn').onclick=()=>handleQr($('manualQr').value);$('manualQr').addEventListener('keydown',e=>{if(e.key==='Enter')handleQr($('manualQr').value);});
    $('exportBtn').onclick=exportProgress;$('resetBtn').onclick=resetProgress;$('menuBtn').onclick=()=>$('sidebar').classList.toggle('mobile-open');
    $('newMoodBtn')?.addEventListener('click',openMoodCheckin);$('moodSaveBtn')?.addEventListener('click',saveMoodCheckin);$('communityCreateBtn')?.addEventListener('click',createGroupChallenge);
    if($('groupMeetAt')){const minDate=new Date(Date.now()+60000);minDate.setMinutes(minDate.getMinutes()-minDate.getTimezoneOffset());$('groupMeetAt').min=minDate.toISOString().slice(0,16);}$('adminNewMissionBtn')?.addEventListener('click',createCustomMission);$('mascotBtn')?.addEventListener('click',()=>cheerMascot());$('campusOfficialMap')?.addEventListener('click',()=>openExternalCampusMap());
    document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();stopScanner();}});
  }
  recordActiveDay();bindEvents();render();
})();

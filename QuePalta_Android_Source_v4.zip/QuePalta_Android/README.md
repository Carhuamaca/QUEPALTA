# Que Palta 2.1 — Android

Aplicación Android para acompañar la integración social de estudiantes ingresantes mediante misiones breves, exploración del campus y retos colaborativos.

## Funciones incluidas

1. **Inicio personalizado:** nombre, carrera, ciclo, nivel, XP, monedas, racha y misión recomendada.
2. **Misiones progresivas:** 12 misiones base, desbloqueo por XP, registro de reflexión y recompensas.
3. **Mapa de orientación:** pabellones y servicios del campus Monterrico con puntos de misiones sugeridos. El dibujo es una versión simplificada; consulta el plano oficial para orientarte con precisión.
4. **Mascota:** mensajes de ánimo, respuesta al completar misiones y animación de celebración.
5. **Logros:** insignias, niveles, XP y monedas virtuales.
6. **Retos en equipo:** creación de actividades, lista local de participantes, registro de participación e invitación mediante el menú de compartir de Android.
7. **Diario emocional:** registro opcional del estado de ánimo y notas personales. Se conserva localmente y no diagnostica ni evalúa la salud mental.
8. **Perfil:** carrera, ciclo, descripción breve, avatar, estadísticas y actividad reciente.
9. **Administración local:** crear y pausar misiones personalizadas en el dispositivo.
10. **Identidad visual:** paleta crema, verde bosque, oliva y coral; tipografía condensada del sistema para titulares, tarjetas menos redondeadas y jerarquía editorial.
11. **Accesibilidad:** texto más grande y reducción de animaciones, guardados como preferencias.

## Datos y límites del prototipo

- SQLite local es la base de datos principal de Android. Se guardan perfil, progreso, misiones completadas, historial, insignias, registros emocionales, retos de equipo y misiones personalizadas.
- El respaldo JSON se puede exportar desde el perfil.
- El acceso con cuenta institucional UPC / Microsoft queda pendiente.
- **No hay cuentas ni sincronización en la nube todavía.** Los retos de equipo y la administración local se guardan en el celular donde se crean. El botón de compartir envía una invitación, pero no crea una sala multiusuario en tiempo real.
- El panel de administración local no tiene autenticación ni permisos remotos y solo debe usarse como herramienta de prototipo.
- El mapa de orientación está simplificado y no reemplaza el plano oficial ni la señalización del campus.
- Las misiones se completan mediante auto-reporte; la app no verifica que una interacción social haya ocurrido.

## Plano del campus

La lista de servicios y pabellones se basa en el documento público de accesibilidad de UPC:

https://www.upc.edu.pe/nosotros/pilares-estrategicos/resultados/documentos/CAMPUS%20UPC%20MONTERRICO_MAPA%20ACCESIBILIDAD.pdf

La biblioteca de Monterrico figura en el Pabellón I y en los pisos 3 y 4 del Pabellón L:

https://explora.upc.edu.pe/es_ES/servicios/%C2%BFdonde-ubico-la-biblioteca-de-mi-campus

## Compilar el APK

Requisitos: JDK 17, Android SDK API 36 y Gradle 8.13.

```bash
gradle --no-daemon -p QuePalta_Android :app:assembleDebug
```

APK de depuración:

`QuePalta_Android/app/build/outputs/apk/debug/app-debug.apk`

Para instalar sobre una versión anterior, conserva el mismo applicationId y usa una versión de firma compatible. El flujo de GitHub Actions genera una compilación debug, no un paquete firmado de publicación para Google Play.

# Notas de versión — Que Palta 2.1

- Rediseño editorial con paleta crema, verde bosque, oliva y acentos coral; se reducen los degradados y las tarjetas genéricas.
- Ajuste del lenguaje de bienvenida y de las misiones para que suene más cercano y menos prefabricado.
- Inicio con misión recomendada, progreso, nivel, monedas y actividad de la semana.
- 12 misiones con buscador y filtro por tema.
- Al completar una misión se puede guardar, de forma opcional, cómo se sintió el estudiante y una nota personal.
- Diario emocional con opción de borrar registros individuales.
- Retos de equipo con fecha propuesta, validación de participantes, seguimiento local, compartir invitación y eliminar planes.
- Preferencias de accesibilidad: texto más grande y reducción de movimiento.
- Reparación de las funciones de la mascota que podían provocar errores al renderizar la pantalla de inicio.
- Navegación móvil revisada y lector de QR manual para las doce misiones.
- Se conserva SQLite local y la migración desde la base de datos anterior.

## Alcance que sigue pendiente

- El acceso con cuenta institucional UPC / Microsoft se deja pendiente, tal como se acordó.
- No hay sincronización entre dispositivos ni un backend multiusuario.
- Los retos de equipo se guardan en el teléfono que los crea; la invitación se puede compartir, pero no sincroniza el avance de los participantes.
- El mapa es orientativo y debe contrastarse con la señalización oficial del campus.
- El lector QR con cámara debe probarse en un dispositivo Android físico.

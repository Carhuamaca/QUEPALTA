# QUE PALTA — Android nativo

**Proyecto Android instalable para el proyecto académico Que Palta.** Es una app híbrida: la interfaz visual se empaqueta dentro de la aplicación y funciona localmente; el almacenamiento SQLite, el acceso a la cámara, el escáner QR y la exportación de datos se realizan desde Android. Incluye las seis misiones, progreso y niveles, insignias, historial, perfil y mapa conceptual del campus.

## Qué está implementado

- Aplicación Android nativa instalable, con interfaz local empaquetada dentro del APK (no necesita abrir un navegador ni conectarse a una web).
- Base SQLite interna (`que_palta.db`) con tablas independientes para perfil, progreso, misiones completadas, reflexiones, historial, días activos e insignias.
- Escáner QR con CameraX y ML Kit. El modelo QR viene integrado en el APK, por lo que el primer escaneo no depende de descargar un modelo adicional.
- Datos locales y funcionamiento sin cuenta: el progreso permanece en el teléfono donde se usa la app.
- Se conservan las seis misiones y los códigos `QP|MISION|01` hasta `QP|MISION|06`.
- Diseño móvil con colores coherentes de Que Palta, tipografía condensada para titulares y jerarquías más legibles.

## Lo que todavía no es

- No hay cuentas, panel de administración, sincronización entre teléfonos ni base de datos en la nube. SQLite es una base real, pero local al dispositivo.
- El mapa es ilustrativo y no es un plano oficial de UPC.
- Registrar una misión es una declaración personal; el QR identifica el reto, no verifica que una actividad social haya ocurrido.
- No es una herramienta clínica ni una aplicación oficial de UPC.

## Cómo generar el APK

Este entorno de trabajo no contiene Android SDK ni Gradle y no permitió descargar esas herramientas. Por eso no sería honesto adjuntar un ZIP o HTML renombrado y decir que es un APK compilado. El proyecto Android queda preparado para compilarse desde Android Studio o GitHub Actions.

### Android Studio

1. Instala Android Studio estable y un JDK 17.
2. Abre la carpeta `QuePalta_Android` con **Open**.
3. Deja que Gradle sincronice el proyecto y acepte la instalación de Android SDK API 36 si Android Studio la solicita.
4. Conecta un Android por USB o crea un emulador.
5. Selecciona la variante `debug` y ejecuta **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio generará el archivo en `app/build/outputs/apk/debug/`.

También puedes usar **Build > Generate Signed Bundle / APK** para firmar una versión de distribución. Para publicar en Google Play se requiere una clave propia y revisar las políticas y requisitos vigentes.

### GitHub Actions (opcional)

Sube esta carpeta a un repositorio GitHub y ejecuta el workflow `Build Android APK`. El resultado `QuePalta-debug-apk` se publicará como artefacto descargable de esa ejecución.

## Configuración técnica

- Application ID: `com.quepalta.app` (la variante debug usa `com.quepalta.app.debug`).
- Min SDK: Android 8.0 (API 26).
- Target SDK: API 35; compile SDK: API 36.
- Android Gradle Plugin: 8.13.2; Gradle: 8.13; JDK: 17.
- CameraX: 1.7.0; ML Kit Barcode Scanning bundled: 17.3.0.
- Base de datos: SQLiteOpenHelper, archivo interno `que_palta.db`.

## Pruebas pendientes antes de llamarla versión final

1. Compilar en Android Studio (la compilación no pudo ejecutarse en este entorno).
2. Instalar en un Samsung y en un dispositivo Android adicional.
3. Probar permiso de cámara, lectura de cada uno de los seis QR y reanudación después de cerrar y abrir la app.
4. Completar/reiniciar misiones y confirmar que XP, insignias, reflexiones e historial siguen guardados.
5. Confirmar accesibilidad, tamaños de texto y comportamiento en pantallas pequeñas.

El código está preparado para esas comprobaciones; hasta realizarlas no debe anunciarse como probado al 100 %.
